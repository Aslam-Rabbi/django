from pages.models import Person
from django.contrib import admin

# Register your models here.

class PersionAdmin(admin.ModelAdmin):
    list_display =['first_name','last_name','phone_number','date_of_birthday','gender','email','adress']
    search_fields = ['first_name','last_name','date_of_birthday','gender']

admin.site.register(Person, PersionAdmin)