from django.db import models


# Create your models here.

class Person(models.Model):
    first_name = models.CharField(max_length=50)
    last_name = models.CharField(max_length=40,blank=True,null=True)
    phone_number =models.CharField(max_length=100)
    date_of_birthday =models.DateField(max_length=20)
    gender =models.CharField(max_length=20)
    email =models.EmailField(unique=True)
    adress =models.TextField(max_length=100)
 

    def __str__(self) :
        return self.phone_number

    