from educations.views import educations
from pages.models import Person
from django.http.response import HttpResponse
from django.shortcuts import redirect, render
from pages.models import Person
from django.contrib import messages


# Create your views here.
def index(request):
    return render(request, 'layouts/home.html')


def about(request):
    return render(request, 'layouts/about.html')


def update(request):
    query1 = Person.objects.all()
    context = {
        "query1": query1

    }
    return render(request, 'layouts/update.html', context)


def edit(request, person_id):
    query1 = Person.objects.get(id=person_id)
    context = {
        "query1": query1
    }
    return render(request, 'layouts/edit.html', context)






def contact(request):
    if request.method == 'POST':
        get_method = request.POST.copy()
        first_name = get_method.get('First_name')
        last_name = get_method.get('last_name')
        phone_number = get_method.get('phone_number')
        date_of_birthday = get_method.get('date_of_birthday')
        gender = get_method.get('Gender')
        email = get_method.get('Email')
        adress = get_method.get('Adress')
        if (phone_number == ""):
            messages.warning(request, "Phone Number Can`t be Blank.")
        elif (first_name == ""):
            messages.warning(request, "First name can`t Blank.")
        elif (email == ""):
            messages.warning(request, "Email must be Taken .")
        elif (gender == ""):
            messages.warning(request, "Gender must be Taken .")
        else:
            person_info = Person.objects.create(first_name=first_name, last_name=last_name, phone_number=phone_number,
                                                date_of_birthday=date_of_birthday, gender=gender, email=email,
                                                adress=adress)
            person_info.save()
            messages.success(request, "Message Sussefull.")
            return redirect('contact')

        # first_name =request.POST['First_name']

    query1 = Person.objects.filter(
        first_name__startswith='R'
    ) | Person.objects.filter(
        last_name__startswith='I'
    )
    query = Person.objects.all();
    context = {
        "query1": query1,
        # "query2":query2,
        "query": query

    }
    return render(request, 'layouts/contact.html', context)


def service(request):
    return render(request, 'layouts/service.html')
