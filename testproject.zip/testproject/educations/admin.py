from django.contrib import admin
from educations.models import Education


# Register your models here.
class EducationAdmin(admin.ModelAdmin):
    list_display =['phone_number','student_id','class_name','department']
    search_fields = ['phone_number','student_id','class_name','department']

admin.site.register(Education, EducationAdmin)