from pages.models import Person
from django.db import models

# Create your models here.
class Education(models.Model):
    phone_number =models.ForeignKey(Person, on_delete=models.CASCADE)
    student_id =models.IntegerField(null=True)
    class_name =models.CharField(max_length=100)
    department =models.CharField(max_length=100)

    def __str__(self) :
        return self.class_name

   